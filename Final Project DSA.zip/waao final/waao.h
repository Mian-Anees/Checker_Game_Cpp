#include <iostream>
    #include <stdlib.h>
    #include <string>
    #include <string.h>
    #include <conio.h>
    #include <stdio.h>
    #include <windows.h>
    #define COUNT 10
    #define m 12
    using namespace std;
    void player_vs_player1v2();
    int board1v2[m][m];
    int p1_dice=m,p2_dice=m;

    struct tree
    {
        int data;int ind_i;int ind_j;
        struct tree *left;struct tree *right;
    }*pl1,*pl2;

    struct tree *create(int data,int i,int j)
    {
        struct  tree *new_node=(tree*)malloc(sizeof(tree));
        new_node->data=data; new_node->ind_i=i; new_node->ind_j=j;
        new_node->left=new_node->right=NULL;
        return new_node;

    }
    struct tree* insert(tree *root,int data,int i,int j)
    {

        if(root==NULL)return create(data,i,j);

        if(data<root->data)
        root->left=insert(root->left,data,i,j);
        else if(data>root->data)
        root->right=insert(root->right,data,i,j);
        return (root);

    };


    struct tree* search(struct tree* root, int data)
    {
        struct  tree *new_node=(tree*)malloc(sizeof(tree));

        if(root->data==data)
        {
        new_node=root;
        return new_node;
        }

        if(data<root->data)
            root=search(root->left,data);
        else if(data>root->data)
            root=search(root->right,data);
    }


    void *update(struct tree* root, int data,int i,int j)
    {
        if(root->data==data)
        {
        root->ind_i=i;
        root->ind_j=j;
        }

        if(data<root->data)
            update(root->left,data,i,j);
        else if(data>root->data)
            update(root->right,data,i,j);
    }

    void print(tree *root, int space)
    {
        if (root == NULL)
            return;
        space += COUNT;
        print(root->right, space);
        cout<<"\n";
        for (int i = COUNT; i < space; i++)
            cout<<" ";
        cout<<root->data<<" "<<root->ind_i<<" "<<root->ind_j<<endl;
        print(root->left, space);
    }


    struct tree* create_tree()
    {
    tree *p1=NULL;
    p1=insert(p1,11,3,5);p1=insert(p1,9,3,3);p1=insert(p1,7,2,8);
    insert(p1,5,2,6);p1=insert(p1,3,2,4);p1=insert(p1,1,2,2);
    p1=insert(p1,13,3,7);p1=insert(p1,15,3,9);p1=insert(p1,17,4,2);
    p1=insert(p1,19,4,4);insert(p1,21,4,6);p1=insert(p1,23,4,8);

    return p1;
    }


    struct tree* create_tree1()
    {
    tree *p2=NULL;
    p2=insert(p2,12,8,6);p2=insert(p2,10,8,8);p2=insert(p2,8,9,3);
    p2=insert(p2,6,9,5);p2=insert(p2,4,9,7);p2=insert(p2,2,9,9);
    p2=insert(p2,14,8,4);p2=insert(p2,16,8,2);p2=insert(p2,18,7,9);
    p2=insert(p2,20,7,7);p2=insert(p2,22,7,5);p2=insert(p2,24,7,3);
    return p2;
    }

    void fill_board1v2()
    {
        int i,j;
        for(i=0;i<m;i++)
        {
            for(j=0;j<m;j++)
            {

                board1v2[i][j]=-1;
            }
        }

    }


    void player1_dicing1v2()
    {
        int i,j;
        int counter=1;
        for(i=2;i<5;i++)
        {
            if(i==3)
            {
            for(j=2+1;j<10;j+=2)
            {

                board1v2[i][j]=counter;
                counter=counter+2;
            }
            }
            else
            {
            for(j=2;j<10;j+=2)
            {

                board1v2[i][j]=counter;
                counter=counter+2;
            }
            }
        }
    }
    void player2_dicing1v2()
    {


        int i,j;
        int counter1=24;
        for(i=7;i<10;i++)
        {
            if(i==8)
            {
            for(j=3-1;j<10;j+=2)
            {
                board1v2[i][j]=counter1;
                counter1=counter1-2;
            }
            }
            else
            {
            for(j=3;j<10;j+=2)
            {
                board1v2[i][j]=counter1;
                counter1=counter1-2;
            }
            }
        }
        }


        void board_display1v2()
    {


        int i,j;
        for(i=2;i<10;i++)
        {
             cout<<"__________________________________________________________________\n";

            for(j=2;j<10;j++)
            {
                cout<< "|";
                if(board1v2[i][j]!=(-1))
                {
                cout<<board1v2[i][j];
                }
               cout<<" \t ";

            }
            cout<<"|";
            cout<<endl;
        }
         cout<<"__________________________________________________________________\n";
    }


    void padding1v2()
    {

        int i,j;
       for(i=0;i<2;i++)
       {
           for(j=0;j<m;j++)
           {
               board1v2[i][j]=50;
           }
       }
        for(i=0;i<m;i++)
       {
           for(j=0;j<2;j++)
           {
               board1v2[i][j]=50;
           }
       }
        for(i=10;i<m;i++)
       {
           for(j=0;j<m;j++)
           {
               board1v2[i][j]=50;
           }
       }
        for(i=0;i<m;i++)
       {
           for(j=10;j<m;j++)
           {
               board1v2[i][j]=50;
           }
       }
    }


    int check_DR(int node,int i,int j)
    {
        i++;j++;
        if(node%2==1)
        {
        if(board1v2[i][j]==50)return 50;
        if((board1v2[i][j]%2)==1)return 50;
        if((board1v2[i][j]%2)==0)return 1;
        if(board1v2[i][j]==-1)return -1;
        }
        else
        {
            if(board1v2[i][j]==50)return 50;
            if((board1v2[i][j]%2)==0)return 50;
            if((board1v2[i][j]%2)==1)return 1;
            if(board1v2[i][j]==-1)return -1;
        }
    }

    int check_DL(int node,int i,int j)
    {
        i++;j--;
        if(node%2==1)
        {
        if(board1v2[i][j]==50)return 50;
        if((board1v2[i][j]%2)==1)return 50;
        if((board1v2[i][j]%2)==0)return 1;
        if(board1v2[i][j]==-1)return -1;
        }
        else
        {
            if(board1v2[i][j]==50)return 50;
            if((board1v2[i][j]%2)==0)return 50;
            if((board1v2[i][j]%2)==1)return 1;
            if(board1v2[i][j]==-1)return -1;
        }
    }

    int check_UL(int node,int i,int j)
    {
        i--;j--;
        if(node%2==1)
        {
        if(board1v2[i][j]==50)return 50;
        if((board1v2[i][j]%2)==1)return 50;
        if((board1v2[i][j]%2)==0)return 1;
        if(board1v2[i][j]==-1)return -1;
        }
        else
        {
            if(board1v2[i][j]==50)return 50;
            if((board1v2[i][j]%2)==0)return 50;
            if((board1v2[i][j]%2)==1)return 1;
            if(board1v2[i][j]==-1)return -1;
        }
    }

    int check_UR(int node,int i,int j)
    {
        i--;j++;
        if(node%2==1)
        {
        if(board1v2[i][j]==50)return 50;
        if((board1v2[i][j]%2)==1)return 50;
        if((board1v2[i][j]%2)==0)return 1;
        if(board1v2[i][j]==-1)return -1;
        }
        else
        {
            if(board1v2[i][j]==50)return 50;
            if((board1v2[i][j]%2)==0)return 50;
            if((board1v2[i][j]%2)==1)return 1;
            if(board1v2[i][j]==-1)return -1;
        }
    }

    void bdisplay()
    {
        int i,j;
        for(i=0;i<m;i++)
        {
            for(j=0;j<m;j++)
            {
                cout<<board1v2[i][j]<<"\t";
            }
            cout<<endl;
        }
    }




void player1_move1v2()
{
        fflush(stdin);
        system("color f");
      int i,j,node,node2,check;
      string ch;
      tree *temp;
      cout<<"Enter Node Number To Move"<<endl;
      cin>>node;
      if(node>=1 && node<=23 && node%2==1)
      {
          temp=search(pl1,node);
          i=temp->ind_i;
          j=temp->ind_j;
          if(i==0)
          {
              cout<<"This Dice is Picked By Opponent "<<endl;
              cout<<"Try Another Dice"<<endl;
              player1_move1v2();
              return;
          }
            if(j==0)
          {
              cout<<"This Dice is Picked By Opponent "<<endl;
              cout<<"Try Another Dice"<<endl;
              player1_move1v2();
              return;
          }
          cout<<"Enter Direction to Move"<<endl;
          cout<<"Down Right 'DR'/'dr"<<endl;
          cout<<"Down Left 'DL'/'dl"<<endl;
          cout<<"Up Right 'UR'/'ur"<<endl;
          cout<<"Up Left 'UL'/'ul"<<endl;
          cin>>ch;
          if(ch=="DR" || ch=="dr")
          {
              if(check_DR(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player1_move1v2();return;
              }
               if(check_DR(node,i,j)==1)
              {
                  i++;j++;
                  node2=board1v2[i][j];
                  check=check_DR(node,i,j);
                  if(check==-1)
                  {
                      i--;j--;
                      board1v2[i][j]=-1;
                      i++;j++;
                      board1v2[i][j]=-1;
                      i++;j++;
                      board1v2[i][j]=node;
                      update(pl1,node,i,j);
                       update(pl2,node2,0,0);
                      p2_dice=p2_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player1_move1v2();
                      return;
                  }
              }
              if(check_DR(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i++;j++;
                board1v2[i][j]=node;
                update(pl1,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="DL" || ch=="dl")
          {
            if(check_DL(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player1_move1v2();return;
              }
               if(check_DL(node,i,j)==1)
              {

                  i++;j--;

                  node2=board1v2[i][j];
                  check=check_DL(node,i,j);
                  if(check==-1)
                  {
                      i--;j++;
                      board1v2[i][j]=-1;
                      i++;j--;
                      board1v2[i][j]=-1;
                      i++;j--;
                      board1v2[i][j]=node;
                      update(pl1,node,i,j);
                      update(pl2,node2,0,0);
                      p2_dice=p2_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player1_move1v2();
                      return;
                  }
              }
              if(check_DL(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i++;j--;
                board1v2[i][j]=node;
                update(pl1,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="UR" || ch=="ur")
          {
             if(check_UR(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player1_move1v2();return;
              }
              if(check_UR(node,i,j)==1)
              {

                  i--;j++;
                  node2=board1v2[i][j];
                  check=check_UR(node,i,j);
                  if(check==-1)
                  {
                      i++;j--;
                      board1v2[i][j]=-1;
                      i--;j++;
                      board1v2[i][j]=-1;
                      i--;j++;
                      board1v2[i][j]=node;
                      update(pl1,node,i,j);
                      update(pl2,node2,0,0);
                      p2_dice=p2_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player1_move1v2();
                      return;
                  }
              }
              if(check_UR(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i--;j++;
                board1v2[i][j]=node;
                update(pl1,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="UL" || ch=="ul")
          {
             if(check_UL(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player1_move1v2();return;
              }
          if(check_UL(node,i,j)==1)
              {

                  i--;j--;
                  node2=board1v2[i][j];
                  check=check_UL(node,i,j);
                  if(check==-1)
                  {
                      i++;j++;
                      board1v2[i][j]=-1;
                      i--;j--;
                      board1v2[i][j]=-1;
                      i--;j--;
                      board1v2[i][j]=node;
                      update(pl1,node,i,j);
                      update(pl2,node2,0,0);
                      p2_dice=p2_dice-1;
                        system("cls");
                       board_display1v2();
                       system("pause");
                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player1_move1v2();
                      return;
                  }
              }
              if(check_UL(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i--;j--;
                board1v2[i][j]=node;
                update(pl1,node,i,j);

                      system("pause");
                return;
              }
      }
      else
      {
          cout<<"Wrong Move"<<endl;
          cout<<"Try Again"<<endl;
          player1_move1v2();
      }
    }
          else
      {
          cout<<"Invalid Move Try Again"<<endl;
          player1_move1v2();
      }


}

    void player2_move1v2()
    {
        fflush(stdin);
        system("color b");
      int i,j,node,node2,check;
      string ch;
      tree *temp;
      cout<<"Enter Node Number To Move"<<endl;
      cin>>node;
      if(node>=2 && node<=24 && node%2==0)
      {
          temp=search(pl2,node);
          i=temp->ind_i;
          j=temp->ind_j;
          if(i==0)
          {
              cout<<"This Dice is Picked By Opponent "<<endl;
              cout<<"Try Another Dice"<<endl;
              player2_move1v2();
              return;
          }
          if(j==0)
          {
              cout<<"This Dice is Picked By Opponent "<<endl;
              cout<<"Try Another Dice"<<endl;
              player2_move1v2();
              return;
          }
          cout<<"Enter Direction to Move"<<endl;
          cout<<"Down Right 'DR'/'dr"<<endl;
          cout<<"Down Left 'DL'/'dl"<<endl;
          cout<<"Up Right 'UR'/'ur"<<endl;
          cout<<"Up Left 'UL'/'ul"<<endl;
          cin>>ch;
           if(ch=="DR" || ch=="dr")
          {
              if(check_DR(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player2_move1v2();return;
              }
                       if(check_DR(node,i,j)==1)
              {
                  i++;j++;
                  node2=board1v2[i][j];
                  check=check_DR(node,i,j);
                  if(check==-1)
                  {
                      i--;j--;
                      board1v2[i][j]=-1;
                      i++;j++;
                      board1v2[i][j]=-1;
                      i++;j++;
                      board1v2[i][j]=node;
                      update(pl2,node,i,j);
                       update(pl1,node2,0,0);
                      p1_dice=p1_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player2_move1v2();
                      return;
                  }
              }
              if(check_DR(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i++;j++;
                board1v2[i][j]=node;
                update(pl2,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="DL" || ch=="dl")
          {
            if(check_DL(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player2_move1v2();return;
              }
              if(check_DL(node,i,j)==1)
              {

                  i++;j--;

                  node2=board1v2[i][j];
                  check=check_DL(node,i,j);
                  if(check==-1)
                  {
                      i--;j++;
                      board1v2[i][j]=-1;
                      i++;j--;
                      board1v2[i][j]=-1;
                      i++;j--;
                      board1v2[i][j]=node;
                      update(pl2,node,i,j);
                      update(pl1,node2,0,0);
                      p1_dice=p1_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player2_move1v2();
                      return;
                  }
              }
              if(check_DL(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i++;j--;
                board1v2[i][j]=node;
                update(pl2,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="UR" || ch=="ur")
          {
             if(check_UR(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player2_move1v2();return;
              }
              if(check_UR(node,i,j)==1)
              {

                  i--;j++;
                  node2=board1v2[i][j];
                  check=check_UR(node,i,j);
                  if(check==-1)
                  {
                      i++;j--;
                      board1v2[i][j]=-1;
                      i--;j++;
                      board1v2[i][j]=-1;
                      i--;j++;
                      board1v2[i][j]=node;
                      update(pl2,node,i,j);
                      update(pl1,node2,0,0);
                      p1_dice=p1_dice-1;
                      system("cls");
                      board_display1v2();

                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player2_move1v2();
                      return;
                  }
              }
              if(check_UR(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i--;j++;
                board1v2[i][j]=node;
                update(pl2,node,i,j);

                      system("pause");
                return;
              }
          }
          if(ch=="UL" || ch=="ul")
          {
             if(check_UL(node,i,j)==50)
              {
                  cout<<"Invalid Move Try Again"<<endl;
                  player1_move1v2();return;
              }
             if(check_UL(node,i,j)==1)
              {

                  i--;j--;
                  node2=board1v2[i][j];
                  check=check_UL(node,i,j);
                  if(check==-1)
                  {
                      i++;j++;
                      board1v2[i][j]=-1;
                      i--;j--;
                      board1v2[i][j]=-1;
                      i--;j--;
                      board1v2[i][j]=node;
                      update(pl2,node,i,j);
                      update(pl1,node2,0,0);
                      p1_dice=p1_dice-1;
                        system("cls");
                       board_display1v2();
                       system("pause");
                      return ;
                  }
                  else
                  {
                      cout<<"There is an opponent Dice"<<endl;
                      cout<<"Play Again"<<endl;
                      player2_move1v2();
                      return;
                  }
              }
              if(check_UL(node,i,j)==-1)
              {
                board1v2[i][j]=-1;
                i--;j--;
                board1v2[i][j]=node;
                update(pl2,node,i,j);

                      system("pause");
                return;
              }
      }
       else
      {
          cout<<"Wrong Move"<<endl;
          cout<<"Try Again"<<endl;
          player2_move1v2();
      }
      }
      else
      {
          cout<<"Invalid Move Try Again"<<endl;
          player2_move1v2();
      }

    }


    void game()
    {
        system("color f");
        int choice;
        fill_board1v2();
        pl1=create_tree();
        pl2=create_tree1();
        player1_dicing1v2();
        player2_dicing1v2();
        padding1v2();


        player_vs_player1v2();

    }

void player_vs_player1v2()
{
system("cls");
while(1)
{
    if(p1_dice<1)
    break;
    if(p2_dice<1)
    break;
    board_display1v2();
    cout<<"Players 1 Dice : "<<p1_dice<<endl;
    cout<<"Players 2 Dice : "<<p2_dice<<endl;
    cout<<"Player 1 Turn"<<endl;
    player1_move1v2();
    system("cls");
    if(p1_dice<1)
    break;
    if(p2_dice<1)
    break;
    board_display1v2();
    cout<<"Players 1 Dice : "<<p1_dice<<endl;
    cout<<"Players 2 Dice : "<<p2_dice<<endl;
    cout<<"Player 2 Turn"<<endl;
    player2_move1v2();
    system("cls");

}
    if(p1_dice>p2_dice)
    {
        cout<<"Player 1 WINS the Game"<<endl;
    }
   else
    {
        cout<<"Player 2 WINS the Game"<<endl;
    }

}


