#include<iostream>
#include<windows.h>
#include<stdlib.h>
#include<conio.h>
#include <time.h>
#include "start.h"
#include "waao.h"

using namespace std;
#define m 10
#define a 12
#define b 5
int x = 0;
int p1hash[a][b];
int p2hash[a][b];
int board[m][m];
void create()
{
	int i, j;
	for (i = 0; i<10; i++)
	{
		for (j = 0; j<10; j++)
		{

			board[i][j] = 0;
		}
	}

}
int check_node_of_own1(int i, int key)
{
	int num;
	if (i == 12)
		return false;

	if (p1hash[i][0] == key)
	{
		return i;
	}

	check_node_of_own1(i + 1, key);
}
int check_node_of_own2(int i, int key)
{
	int num;
	if (i == 12)
		return false;

	if (p2hash[i][0] == key)
	{
		return i;
	}

	check_node_of_own2(i + 1, key);
}
void player1()
{
	int i = 0, j = 0;
	int counter = 0;
	int num = 0;
	for (i = 1; i<4; i++)
	{
		if (i == 2)
		{
			for (j = 2; j<9; j++)
			{
				counter++;
				counter++;
				board[i][j] = counter;
				p1hash[num][0] = counter;
				p1hash[num][1] = i;
				p1hash[num][2] = j;
				p1hash[num][3] = -1;
				p1hash[num][4] = 50;
				num++;
				j++;
			}
		}
		else
		{
			for (j = 1; j<9; j++)
			{
				counter++;
				counter++;
				board[i][j] = counter;
				p1hash[num][0] = counter;
				p1hash[num][1] = i;
				p1hash[num][2] = j;
				p1hash[num][3] = -1;
				p1hash[num][4] = 50;
				num++;
				j++;
			}
		}

	}
}
void uphashp1(int r, int c, int key, int i, int life)
{
	if (i == 12)
		return;


	int num = check_node_of_own1(0, key);
	if (life == -2)
	{
		p1hash[num][3] = -2;
	}


	else if (p1hash[num][0] == key)
	{
		p1hash[num][1] = r;
		p1hash[num][2] = c;
	}


}
void uphashp2(int r, int c, int key, int i, int life)
{
	if (i == 12)
		return;


	int num = check_node_of_own2(0, key);


	if (life == -2)
	{
		p2hash[num][3] = -2;
	}

	else if (p2hash[num][0] == key)
	{

		p2hash[num][1] = r;
		p2hash[num][2] = c;
	}
}
void player2()
{
	int i = 0, j = 0;
	int counter = 3;
	int num = 0;
	for (i = 6; i<9; i++)
	{
		if (i == 6 || i == 8)
		{
			for (j = 2; j<9; j++)
			{
				counter++;
				counter++;
				board[i][j] = counter;
				p2hash[num][0] = counter;
				p2hash[num][1] = i;
				p2hash[num][2] = j;
				p2hash[num][3] = -1;
				p2hash[num][4] = 50;
				num++;

				j++;
			}
		}
		else
		{
			for (j = 1; j<9; j++)
			{
				counter++;
				counter++;
				board[i][j] = counter;
				p2hash[num][0] = counter;
				p2hash[num][1] = i;
				p2hash[num][2] = j;
				p2hash[num][3] = -1;
				p2hash[num][4] = 50;
				num++;
				j++;
			}
		}

	}
}
bool check_node_of_opponent(int i, int j)
{
	int num = (board[i][j]) % 2;
	if (num == 1)
	{
		return true;

	}
	else
		return false;

}
bool check_oppont_border(int i, int key)
{
	if (i == 12)
	{
		return false;
	}
	if (p1hash[i][0] == key)
	{
		if (p1hash[i][1] == 8)
		{
			p1hash[i][4] = 51;
			return true;

		}
		else if (p1hash[i][4] == 51)
		{
			return true;
		}
	}
	check_oppont_border(i + 1, key);
}


void display()
{


	int i, j;
	for (i = 1; i<9; i++)
	{
		cout << "__________________________________________________________________________________________________________________________________\n";

		for (j = 1; j<9; j++)
		{
			cout << "|";
			cout << "\t" ;
			if (board[i][j] != 0)
			{
				cout << board[i][j];
			}
			cout << " \t ";

		}
		cout << "|";
		cout << endl;
	}
	cout << "__________________________________________________________________________________________________________________________________\n";
}
void display2()
{
	int i, j;
	for (i = 0; i<12; i++)
	{
		for (j = 0; j<5; j++)
		{
			cout << p1hash[i][j] << "\t";
			cout << p2hash[i][j] << "\t" << endl;
		}
		cout << endl;
	}
}
int run(int i, int j, int key)
{
	char ch;
	char choice;
	//for 4 moves
	if (check_oppont_border(0, key))
	{

		cout << "you have four moves right now , up left (h)or right(k) ,down left(l) or right(r):" << endl;
		cout << "chose one move " << endl;
		cin >> choice;
		if (choice == 'h' || choice == 'H')
		{
			if (board[i - 1][j - 1] == 0 && board[i - 1][j - 1] != 1)
			{
				board[i][j] = 0;
				board[i - 1][j - 1] = key;
				uphashp1(i - 1, j - 1, key, 0, -1);

			}
			else if (board[i - 2][j - 2] == 0)
			{
				if (check_node_of_opponent(i - 1, j - 1))
				{
					int numk = board[i - 1][j - 1];

					board[i - 1][j - 1] = 0;
					board[i][j] = 0;
					board[i - 2][j - 2] = key;
					uphashp1(i - 2, j - 2, key, 0, -1);
					uphashp2(i - 1, j - 1,numk, 0, -2);

				}
				else
				{
					cout << "invalid move " << endl;
					system("pause");
				}

			}
			else
			{
				cout << "invalid move " << endl;
				system("pause");
			}
		}
		else if (choice == 'k' || choice == 'K')
		{
			if (board[i - 1][j + 1] == 0 && board[i - 1][j + 1] != 1)
			{
				board[i][j] = 0;
				board[i - 1][j + 1] = key;
				uphashp1(i - 1, j + 1, key, 0, -1);

			}
			else if (board[i - 2][j + 2] == 0)
			{
				if (check_node_of_opponent(i - 1, j + 1))
				{

					board[i][j] = 0;
					int numkk = board[i - 1][j + 1];
					board[i - 1][j + 1] = 0;
					board[i - 2][j + 2] = key;
					uphashp1(i - 2, j + 2, key, 0, -1);
					uphashp2(i - 1, j + 1, numkk, 0, -2);


				}
				else
				{
					cout << "invalid move " << endl;
					system("pause");
				}

			}
			else
			{
				cout << "invalid move " << endl;
				system("pause");
			}
		}
		else if (choice == 'r' || choice == 'R')
		{
			if (board[i + 1][j + 1] == 0)
			{

				board[i][j] = 0;
				board[i + 1][j + 1] = key;
				uphashp1(i + 1, j + 1, key, 0, -1);
			}
			else if (board[i + 1][j + 1] != 0 && board[i + 1][j + 1] != 1)
			{
				if (check_node_of_opponent(i + 1, j + 1))
				{
					if (board[i + 2][j + 2] == 0)
					{

						board[i + 2][j + 2] = board[i][j];
						uphashp1(i + 2, j + 2, key, 0, -1);
						uphashp2(i + 1, j + 1, board[i + 1][j + 1], 0, -2);
						board[i + 1][j + 1] = 0;
						board[i][j] = 0;
					}

				}
			}

			else
			{
				cout << "invalid move " << endl;
				cout << "try again " << endl;
				system("pause");
			}

		}


		else if (choice == 'l' || choice == 'L')
		{
			if (board[i + 1][j - 1] == 0)
			{
				board[i + 1][j - 1] = key;
				board[i][j] = 0;
				uphashp1(i + 1, j - 1, key, 0, -1);
			}
			else if (board[i + 2][j - 2] == 0 && board[i + 2][j - 2] != 1)
			{
				if (check_node_of_opponent(i + 1, j - 1))
				{
					if (board[i + 2][j - 2] == 0)
					{
						board[i + 2][j - 2] = board[i][j];
						uphashp1(i + 2, j - 2, key, 0, -1);
						uphashp2(i + 1, j - 1, board[i + 1][j - 1], 0, -2);
						board[i][j] = 0;
						board[i + 1][j - 1] = 0;
					}

				}
			}
			else
			{
				cout << "invalid move " << endl;
				cout << "try again " << endl;
				system("pause");
			}
		}
		else
			cout << "invalid move " << endl;
		system("pause");

	}
	//for only 2 moves
	else
	{

		cout << "which step you want to move forward ,press(R,L):" << endl;
		cin >> ch;
		if (ch == 'r' || ch == 'R')
		{
			if (board[i + 1][j + 1] == 0)
			{

				board[i][j] = 0;
				uphashp1(i + 1, j + 1, key, 0, -1);
				board[i + 1][j + 1] = key;

			}
			else if (board[i + 1][j + 1] != 0 && board[i + 1][j + 1] != 1)
			{
				if (check_node_of_opponent(i + 1, j + 1))
				{
					if (board[i + 2][j + 2] == 0)
					{
						int p2key = board[i + 1][j + 1];
						uphashp2(i + 1, j + 1, p2key, 0, -2);
						board[i + 2][j + 2] = board[i][j];
						uphashp1(i + 2, j + 2, key, 0, -1);
						board[i + 1][j + 1] = 0;
						board[i][j] = 0;
					}

				}
			}

			else
			{
				cout << "invalid move " << endl;
				cout << "try again " << endl;
				system("pause");
			}

		}


		if (ch == 'l' || ch == 'L')
		{
			if (board[i + 1][j - 1] == 0)
			{
				board[i][j] = 0;
				board[i + 1][j - 1] = key;
				uphashp1(i + 1, j - 1, key, 0, -1);
			}
			else if (board[i + 2][j - 2] == 0 && board[i + 2][j - 2] != 1)
			{

				if (check_node_of_opponent(i + 1, j - 1))
				{
					if (board[i + 2][j - 2] == 0)
					{
						board[i + 2][j - 2] = board[i][j];
						uphashp1(i + 2, j - 2, key, 0, -1);
						uphashp2(i + 1, j - 1, board[i + 1][j - 1], 0, -2);
						board[i][j] = 0;
						board[i + 1][j - 1] = 0;
					}


				}
			}
			else
			{
				cout << "invalid move " << endl;
				cout << "try again " << endl;
				system("pause");
			}
		}

	}
	return true;
}


int recurssive_search_node(int i, int key)
{

	if (i == 12)
	{
		return false;
	}
	else if (p1hash[i][0] == key && p1hash[i][3] != -2)
	{

		run(p1hash[i][1], p1hash[i][2], key);
		return true;

	}

	recurssive_search_node(i + 1, key);

}

bool compare_left(int i, int j)
{
	int i_number = (p2hash[j][1]) - 1;
	int j_number = (p2hash[j][2]) - 1;
	if (p1hash[i][1] == i_number && p1hash[i][2] == j_number)
	{
		if (p1hash[i][3] != -2)
		{
			if (p2hash[j][3] != -2)
			{
				int i_in = (p2hash[j][1]) - 2;
				int j_in = (p2hash[j][2]) - 2;
				if ((board[i_in][j_in]) == 0)
				{
					board[i_in][j_in] = board[p2hash[j][1]][p2hash[j][2]];
					board[p2hash[j][1]][p2hash[j][2]] = 0;
					board[i_number][j_number] = 0;
					uphashp1(i_number, j_number, p1hash[i][0], 0, -2);
					uphashp2(i_in, j_in, p2hash[j][0], 0, -1);


					if (p2hash[j][1] == 1 && p2hash[j][4] == 50)
					{
						p2hash[j][4] = 51;
						return true;
					}
					else
						return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
	}
	else
	{
		return false;
	}
}
bool compare_right(int i, int j)
{
	int i_number = (p2hash[j][1]) - 1;
	int j_number = (p2hash[j][2]) + 1;
	if (p1hash[i][1] == i_number && p1hash[i][2] == j_number)
	{
		if (p1hash[i][3] != -2)
		{
			if (p2hash[j][3] != -2)
			{
				int i_in = (p2hash[j][1]) - 2;
				int j_in = (p2hash[j][2]) + 2;
				if ((board[i_in][j_in]) == 0)
				{
					board[i_in][j_in] = board[p2hash[j][1]][p2hash[j][2]];
					board[p2hash[j][1]][p2hash[j][2]] = 0;
					board[i_number][j_number] = 0;
					uphashp1(i_number, j_number, p1hash[i][0], 0, -2);
					uphashp2(i_in, j_in, p2hash[j][0], 0, -1);


					if (p2hash[j][1] == 1 && p2hash[j][4] == 50)
					{
						p2hash[j][4] = 51;
					}
					return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
	}
	else
	{
		return false;
	}
}
bool compare_down_right(int i, int j)
{
	int i_number = (p2hash[j][1]) + 1;
	int j_number = (p2hash[j][2]) + 1;
	if (p1hash[i][1] == i_number && p1hash[i][2] == j_number)
	{
		if (p1hash[i][3] != -2)
		{
			if (p2hash[j][3] != -2)
			{
				int i_in = (p2hash[j][1]) + 2;
				int j_in = (p2hash[j][2]) + 2;
				if ((board[i_in][j_in]) == 0)
				{
					board[i_in][j_in] = board[p2hash[j][1]][p2hash[j][2]];
					board[p2hash[j][1]][p2hash[j][2]] = 0;
					board[i_number][j_number] = 0;
					uphashp1(i_number, j_number, p1hash[i][0], 0, -2);
					uphashp2(i_in, j_in, p2hash[j][0], 0, -1);

					return true;
				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
	}
	else
	{
		return false;
	}
}
bool down_left_move(int i, int j)
{
	int i_number = (p2hash[j][1]) + 1;
	int j_number = (p2hash[j][2]) - 1;
	if (p1hash[i][1] == i_number && p1hash[i][2] == j_number)
	{
		if (p1hash[i][3] != -2)
		{
			if (p2hash[j][3] != -2)
			{
				int i_in = (p2hash[j][1]) + 2;
				int j_in = (p2hash[j][2]) - 2;
				if ((board[i_in][j_in]) == 0)
				{
					board[i_in][j_in] = board[p2hash[j][1]][p2hash[j][2]];
					board[p2hash[j][1]][p2hash[j][2]] = 0;
					board[i_number][j_number] = 0;
					uphashp1(i_number, j_number, p1hash[i][0], 0, -2);

					uphashp2(i_in, j_in, p2hash[j][0], 0, -1);

					return true;

				}
				else
					return false;
			}
			else
				return false;
		}
		else
			return false;
	}

	else
	{
		return false;
	}
}
bool run_p2(int i, int j)
{
	if (p2hash[j][4] == 50)
	{
		if (compare_left(i, j))
		{
			return true;
		}
		else if (compare_right(i, j))
		{
			return true;
		}
		return false;
	}
	else
	{
		if (compare_left(i, j))
		{

			return true;

		}
		else if (compare_right(i, j))
		{

			return true;
		}
		else if (compare_down_right(i, j))
		{

			return true;
		}
		else if (down_left_move(i, j))
		{

			return true;
		}
		return false;

	}

}

bool search_p2_nodes(int i, int j)
{
	if (i == 12)
	{
		if (j == 11)
		{
			return false;
		}
	}
	if (i != 12)
	{

		if (run_p2(i, j))
		{

			return true;
		}
		search_p2_nodes(i + 1, j);

	}
	else if (j != 11)
	{
		search_p2_nodes(0, j + 1);
	}


}
void player1_move()
{
	int node;
	cout << "Player 1 Turn Now " << endl;
	cout << "Enter Dice number you want to move " << endl;
	cin >> node;
	recurssive_search_node(0, node);
}
bool single_move_p2(int j)
{
	int i = rand() % 12;


	if (p2hash[i][4] == 50)
	{
		if ((x % 2) == 0)
		{

			if (board[p2hash[i][1] - 1][p2hash[i][2] - 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] - 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1] = p2hash[i][1] - 1;
				p2hash[i][2] = p2hash[i][2] - 1;
				if (p2hash[i][1] == 1)
				{
					p2hash[i][4] = 51;
				}
				x++;
				return true;
			}
			else if (board[p2hash[i][1] - 1][p2hash[i][2] + 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] + 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1] = p2hash[i][1] - 1;
				p2hash[i][2] = p2hash[i][2] + 1;
				if (p2hash[i][1] == 1)
				{
					p2hash[i][4] = 51;
				}
				x++;
				return true;


			}

		}
		else
		{
			if (board[p2hash[i][1] - 1][p2hash[i][2] + 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] + 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1] = p2hash[i][1] - 1;
				p2hash[i][2] = p2hash[i][2] + 1;
				x++;
				if (p2hash[i][1] == 1)
				{
					p2hash[i][4] = 51;
				}
				return true;


			}
			else if (board[p2hash[i][1] - 1][p2hash[i][2] - 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] - 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1] = p2hash[i][1] - 1;
				p2hash[i][2] = p2hash[i][2] - 1;
				x++;
				if (p2hash[i][1] == 1)
				{
					p2hash[i][4] = 51;
				}
				return true;
			}
		}
	}
	//four moves of Ai in single stepup
	else
	{
		if ((x % 2) == 0)
		{
			if (board[p2hash[i][1] - 1][p2hash[i][2] - 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] - 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1]--;
				p2hash[i][2]--;
				x++;
				return true;
			}

			else if (board[p2hash[i][1] + 1][p2hash[i][2] + 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] + 1][p2hash[i][2] + 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1]++;
				p2hash[i][2]++;
				x++;
				return true;


			}
		}
		else {
			if (board[p2hash[i][1] - 1][p2hash[i][2] + 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] - 1][p2hash[i][2] + 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1]--;
				p2hash[i][2]++;

				x++;
				return true;


			}
			else if (board[p2hash[i][1] + 1][p2hash[i][2] - 1] == 0 && p2hash[i][3] != -2)
			{


				board[p2hash[i][1] + 1][p2hash[i][2] - 1] = p2hash[i][0];

				board[p2hash[i][1]][p2hash[i][2]] = 0;
				cout << board[p2hash[i][1]][p2hash[i][2]];
				p2hash[i][1]++;
				p2hash[i][2]--;
				x++;

				return true;


			}
		}

	}

	single_move_p2(j);

}
void player_2_move()
{
	cout << "Player 2 Turn Now " << endl;
	cout << "wait a second " << endl;
	Sleep(5000);

	if (search_p2_nodes(0, 0))
	{

	}
	else
	{
		single_move_p2(0);

	}


}
void padding()
{

	int i, j;
	for (j = 0; j<10 + 1; j++)
	{
		board[0][j] = 1;
	}for (i = 0; i<10 + 2; i++)
	{
		board[i][9] = 1;
	}
	for (j = 10; j >= 0; j--) {
		board[8 + 1][j] = 1;
	}
	for (i = 0; i<10; i++)
	{
		for (j = 0; j<10; j++)
		{
			if (i == 0 || j == 0)
			{
				board[i][j] = 1;
			}
		}
	}
}
int check_win1(int i)
{
	if (i == 12)
	{
		return 1;
	}
	if (p1hash[i][3] == -2)
	{
		check_win1(i + 1);
	}
	else
		return 0;

}
int check_win2(int i)
{
	if (i == 12)
	{
		return 2;
	}
	if (p2hash[i][3] == -2)
	{
		check_win2(i + 1);
	}
	else
		return 0;

}
bool check_win()
{
	if (1 == check_win1(0))
	{
		cout << "Player 2 won the Game !!!!!" << endl;
		system("pause");
		return true;
	}
	else if (2 == check_win2(0))
	{
		cout << "Player 1 won the Game !!!!" << endl;
		system("pause");
		return true;
	}
	else
		return false;
}
int main()
{

    int choice;



	cout<<"\t\t\t Main Menu "<<endl;
	cout<<"\t\t"<<"press 1 to play double player checkers "<<endl;
	cout<<"\t\t"<<"press 2 to play with computer AI "<<endl;
	cout<<"\t\t"<<"press 3 to exit "<<endl;
	cout<<"\t\t"<<"enter your choice"<<endl;
	cin>>choice;
	switch(choice)
	{
    case 1:
        {
            system("pause");
        starting();
        game();
        break;
        }

	case 2:
        {

        system("color A");
	create();
	starting();
	system("cls");
	padding();
	player1();
	player2();
	display();
	system("pause");
	while ( 1)
	{
		system("color A");
		player1_move();
		system("cls");
		display();
		system("color B");
		player_2_move();
		system("cls");
		display();
		Sleep(1000);
		system("pause");
		//display2();
		if (check_win())
		{
			break;
		}


	}
	break;
        }
        case 3:
        exit(0);
	}
}

