#include <iostream>
#include <windows.h>
using namespace std;
void diagnolstars()
{
	for (int y = 1; y <= 12; y++)
	{
	    cout<<"\t\t\t\t\t\t    ";
		for(int s = 12-y; s>0; s--)
		{
			cout<<"  "; //two spaces
		}
        for(int x = 1; x <= y; x++)
        {
          cout<<"*"<<" ";
        }
        cout<<endl;
	}
}

void straightbar()
{
    int i,j;
    for(i=0;i<4;i++)
    {
        cout<<"\t\t\t\t\t\t";
      for(int j=0;j<15;j++)
      {
        cout<<"*"<<" ";
      }
      cout<<endl;
    }
}
void standingbar()
{
    int i,j;
    for(i=0;i<8;i++)
    {
        cout<<"\t\t\t\t\t\t\t\t\t";
        for(j=0;j<4;j++)
        {
            cout<<"*"<<" ";
        }
        cout<<endl;
    }
}
void one()
{
    diagnolstars();
    int i,j;
    for(i=0;i<24;i++)
    {
        cout<<"\t\t\t\t\t\t\t\t\t\b";
        for(j=0;j<6;j++)
        {
            cout<<"*"<<" ";
        }
        cout<<endl;
    }
    for(i=0;i<6;i++)
    {
        cout<<"\t\t\t\t\t\t";
      for(int j=0;j<16;j++)
      {
        cout<<"*"<<" ";
      }
      cout<<endl;
    }
}
void two()
{
    int i,j;
    for(i=0;i<40;i++)
        cout<<endl;
    for(i=0;i<4;i++)
    {
        cout<<"\t\t\t\t\t\t";
      for(int j=0;j<15;j++)
      {
        cout<<"*"<<" ";
      }
      cout<<endl;
    }
    for(i=0;i<8;i++)
    {
        cout<<"\t\t\t\t\t\t\t\t\t";
        for(j=0;j<4;j++)
        {
            cout<<"*"<<" ";
        }
        cout<<endl;
    }
    for(i=0;i<4;i++)
    {
        cout<<"\t\t\t\t\t\t";
      for(int j=0;j<15;j++)
      {
        cout<<"*"<<" ";
      }
      cout<<endl;
    }
    for(i=0;i<8;i++)
    {
        cout<<"\t\t\t\t\t\t";
        for(j=0;j<4;j++)
        {
            cout<<"*"<<" ";
        }
        cout<<endl;
    }
    for(i=0;i<4;i++)
    {
        cout<<"\t\t\t\t\t\t";
      for(int j=0;j<15;j++)
      {
        cout<<"*"<<" ";
      }
      cout<<endl;
    }
}
void three()
{
    int i,j;
    for(i=0;i<40;i++)
        cout<<endl;

    straightbar();
    standingbar();
    straightbar();
    standingbar();
    straightbar();
}
void starting()
{
    one();
    Sleep(1000);
    system("cls");
    two();
    Sleep(1000);
    system("cls");
    three();
    Sleep(1000);
cout << "\n\n\n\t\t\tPlease Wait Your Game is Loading";
	char a = 177, b = 219;
	cout << "\t\t\t\t";
	for (int i = 0; i <= 15; i++)
	{
		cout << b;
		for (int j = 0; j <= 1e8; j++)
		{ }
	}
}
